import { ApiResponse } from "@repo/types";
import { Payment } from "@repo/types";
import axiosAdmin from "../axios/axiosAdmin";

export const paymentAdminApi = {
  async getAllPayments(): Promise<Payment[]> {
    const data = await axiosAdmin.get<any, ApiResponse<Payment[]>>("/payments");
    return data.result || [];
  },

  async confirmPayment(id: string, transactionCode: string): Promise<void> {
    await axiosAdmin.post(`/payments/${id}/confirm`, null, {
      params: {
        transactionCode,
      },
    });
  },
};
