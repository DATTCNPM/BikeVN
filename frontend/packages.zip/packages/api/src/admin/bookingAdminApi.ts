// src/apis/bookingApi.ts

import axiosAdmin from "../axios/axiosAdmin";

import type { ApiResponse, Booking } from "@repo/types";

export const bookingAdminApi = {
  async getAllBooking(): Promise<Booking[]> {
    const data = await axiosAdmin.get<any, ApiResponse<Booking[]>>("/booking");
    return data.result || [];
  },
};
